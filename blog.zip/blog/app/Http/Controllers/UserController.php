<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

use App\User as user;
class UserController extends Controller
{
    /**
     * Register new user
     *
     * @param $request Request
     */
    public function register(Request $request)
    {
        
        $hasher = app()->make('hash');
        $email = $request->input('email');
        $register = User::create([
            'email'=> $email
        ]);
        if ($register) {
            $res['success'] = true;
            $res['message'] = 'Success register!';
            return response($res);
        }else{
            $res['success'] = false;
            $res['message'] = 'Failed to register!';
            return response($res);
        }

    }
    /**
     * Get user by id
     *
     * URL /user/{id}
     */
    public function authenticate(Request $request)
    {
       	
       	$hasher = app()->make('hash');
        $email = $request->input('email');
        $login = User::where('email', $email)->first();
        if (!$login) {
            $res['success'] = false;
            $res['message'] = 'Your email  incorrect!';
            return response($res);
        }else{
            if ($email == $login->email) {
                $api_token = base64_encode(str_random(40));
                $create_token = User::where('id', $login->id)->update(['api_token' => $api_token]);
                if ($create_token) {
                    $res['success'] = true;
                    $res['api_token'] = $api_token;
                    $res['message'] = $login;
                    return response($res);
                }
            }else{
                $res['success'] = true;
                $res['message'] = 'You email or password incorrect!';
                return response($res);
            }
        }

    }

    public function logout(Request $request)
    {   

        $key = $request->header('Authorization');
         if ($user = User::where('api_token', $key)->update(['api_token' => null])) {
            
                $res['success'] = true;
                $res['message'] = 'Logout success';
                return response($res);
        }else{
            $res['success'] = true;
            $res['message'] = 'failed';
            return response($res);
        }
    }
}