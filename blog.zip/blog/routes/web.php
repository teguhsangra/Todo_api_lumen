<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

// $app->get('/', function () use ($app) {
//     return $app->version();
// });
// $app->get('/key', function() {
//     return str_random(32);
// });
$app->post('register/','UserController@register');	
$app->group(['prefix' => 'api/'], function ($app) {
$app->post('register/','UserController@register');	
$app->get('login/','UserController@authenticate');
$app->get('logout/','UserController@logout');
$app->post('todo/','TodoController@store');
$app->get('todo/', 'TodoController@index');
$app->get('todo/{id}/', 'TodoController@show');
$app->put('todo/{id}/', 'TodoController@update');
$app->put('todo/{id}/completness', 'TodoController@toogle');
$app->delete('todo/{id}/', 'TodoController@destroy');

});